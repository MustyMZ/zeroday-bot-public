import time
from config import BINANCE_API_KEY, BINANCE_API_SECRET

def run_bot():
    print("ZER0DAY bot çalışıyor...")
    while True:
        print("Market kontrol ediliyor...")
        time.sleep(10)

if __name__ == "__main__":
    run_bot()