# ZER0DAY BOT

Binance üzerinde çalışan tam otomatik Python trading botu.